using System.Collections;
using System.Collections.Generic;

[System.Serializable]
public struct Bounds
{
    public float min;
    public float max;
}
