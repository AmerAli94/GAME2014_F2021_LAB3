using System.Collections;
using System.Collections.Generic;

[System.Serializable]

public enum BulletDirection
{
    UP,
    RIGHT,
    DOWN,
    LEFT
}
